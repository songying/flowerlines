#!/usr/bin/env bash
# Test suite for resize.sh
# Creates temporary PNG files of various sizes, runs resize.sh, and verifies output.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RESIZE_SCRIPT="$SCRIPT_DIR/resize.sh"
TARGET_W=1284
TARGET_H=2778
PASS=0
FAIL=0

# Create a solid-color PNG of given WxH using sips (no extra deps needed).
make_png() {
  local path="$1" w="$2" h="$3"
  # Create via Python one-liner (stdlib only, no Pillow needed)
  python3 - "$path" "$w" "$h" <<'PYEOF'
import sys, struct, zlib

def make_png(path, w, h):
    def chunk(tag, data):
        c = struct.pack('>I', len(data)) + tag + data
        return c + struct.pack('>I', zlib.crc32(c[4:]) & 0xffffffff)
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)
    row = b'\x00' + b'\xff\x00\x00' * w  # red pixels, filter byte 0
    raw = row * h
    idat = zlib.compress(raw)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n')
        f.write(chunk(b'IHDR', ihdr))
        f.write(chunk(b'IDAT', idat))
        f.write(chunk(b'IEND', b''))

make_png(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]))
PYEOF
}

check() {
  local label="$1" path="$2"
  local w h
  w=$(sips -g pixelWidth  "$path" | awk '/pixelWidth/{print $2}')
  h=$(sips -g pixelHeight "$path" | awk '/pixelHeight/{print $2}')
  if [ "$w" -eq "$TARGET_W" ] && [ "$h" -eq "$TARGET_H" ]; then
    echo "  PASS  $label  (${w}x${h})"
    PASS=$((PASS+1))
  else
    echo "  FAIL  $label  expected ${TARGET_W}x${TARGET_H}, got ${w}x${h}"
    FAIL=$((FAIL+1))
  fi
}

TMPDIR_TEST=$(mktemp -d)
trap 'rm -rf "$TMPDIR_TEST"' EXIT

echo "=== resize-for-appstore test suite ==="

# Test 1: larger image (typical iPhone screenshot)
make_png "$TMPDIR_TEST/snapshot1.png" 1320 2868
bash "$RESIZE_SCRIPT" "$TMPDIR_TEST"
check "crop 1320x2868 -> ${TARGET_W}x${TARGET_H}" "$TMPDIR_TEST/snapshot1.png"

# Test 2: slightly different width (odd pixel count)
make_png "$TMPDIR_TEST/snapshot2.png" 1319 2868
bash "$RESIZE_SCRIPT" "$TMPDIR_TEST"
check "crop 1319x2868 -> ${TARGET_W}x${TARGET_H}" "$TMPDIR_TEST/snapshot2.png"

# Test 3: already correct size — should stay unchanged
make_png "$TMPDIR_TEST/snapshot3.png" 1284 2778
bash "$RESIZE_SCRIPT" "$TMPDIR_TEST"
check "no-op 1284x2778 -> ${TARGET_W}x${TARGET_H}" "$TMPDIR_TEST/snapshot3.png"

# Test 4: no files in directory — script should exit with error
EMPTY_DIR=$(mktemp -d)
output=$(bash "$RESIZE_SCRIPT" "$EMPTY_DIR" 2>&1 || true)
if echo "$output" | grep -q "No snapshot"; then
  echo "  PASS  no snapshot*.png files -> prints error message"
  PASS=$((PASS+1))
else
  echo "  FAIL  no snapshot*.png files -> expected error message"
  FAIL=$((FAIL+1))
fi
rm -rf "$EMPTY_DIR"

echo ""
echo "Results: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
