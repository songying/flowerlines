#!/usr/bin/env bash
# Resize all snapshot*.png files in BASE_DIR to 1284x2778 using center-crop.
# Usage: resize.sh [base_dir]
#   base_dir defaults to the current working directory.

set -euo pipefail

BASE_DIR="${1:-.}"
TARGET_W=1284
TARGET_H=2778

shopt -s nullglob
files=("$BASE_DIR"/snapshot*.png)

if [ ${#files[@]} -eq 0 ]; then
  echo "No snapshot*.png files found in: $BASE_DIR"
  exit 1
fi

echo "Resizing ${#files[@]} file(s) to ${TARGET_W}x${TARGET_H} ..."

for f in "${files[@]}"; do
  orig=$(sips -g pixelWidth -g pixelHeight "$f" | awk '/pixelWidth/{w=$2} /pixelHeight/{h=$2} END{print w"x"h}')
  sips -c "$TARGET_H" "$TARGET_W" "$f" > /dev/null
  echo "  $f  ($orig -> ${TARGET_W}x${TARGET_H})"
done

echo "Done."
