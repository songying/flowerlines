---
name: resize-for-appstore
description: Resizes all snapshot*.png files in the project base folder to the App Store required screenshot size of 1284x2778 pixels by center-cropping evenly from all four sides. This skill should be used when the user asks to resize, crop, or prepare App Store screenshots matching the pattern snapshot*.png.
---

# Resize for App Store

## Overview

Center-crop all `snapshot*.png` files in the working directory to **1284×2778** (iPhone 6.5" App Store screenshot size) using macOS `sips`. No external dependencies required.

## Workflow

To resize screenshots, run the bundled script:

```bash
bash scripts/resize.sh [base_dir]
```

- `base_dir` defaults to the current working directory if omitted.
- The script edits files **in-place** and prints each file's before/after dimensions.
- Uses `sips -c <height> <width>` which performs a **center crop**, removing pixels evenly from all four sides.

### Example

```
Resizing 4 file(s) to 1284x2778 ...
  snapshot1.png  (1320x2868 -> 1284x2778)
  snapshot2.png  (1320x2868 -> 1284x2778)
  snapshot3.png  (1319x2868 -> 1284x2778)
  snapshot4.png  (1320x2868 -> 1284x2778)
Done.
```

## Running Tests

To verify the script works correctly:

```bash
bash scripts/test_resize.sh
```

The test suite:
1. Creates temporary PNG files at typical iPhone screenshot sizes (1320×2868, 1319×2868)
2. Runs `resize.sh` and verifies output is exactly 1284×2778
3. Verifies a file already at target size is handled correctly
4. Verifies the script reports an error when no `snapshot*.png` files are found

All tests run in a temporary directory and clean up after themselves.

## Notes

- **macOS only** — uses the built-in `sips` tool (no Pillow or ImageMagick needed).
- If the source image is smaller than 1284×2778 in either dimension, `sips` will not enlarge it — the output will be clamped to the source size. Ensure source screenshots are larger than the target.
- After resizing, commit and push the updated files to GitHub as usual.
